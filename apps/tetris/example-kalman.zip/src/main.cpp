#include "ofApp.h"

int main() {
	ofSetupOpenGL(640 * 2, 960, OF_WINDOW);
	ofRunApp(new ofApp());
}
